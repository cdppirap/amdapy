# amdapy

Python package for AMDA
=======================

`amdapy` is a python package for accessing heliophysics data stored on the AMDA plateform.

Installation
------------

Install with pip 

  ``pip3 install amdapy
  ``
